var require = meteorInstall({"imports":{"api":{"tasks.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// imports/api/tasks.js                                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.export({
    Tasks: () => Tasks
});
let Meteor;
module.watch(require("meteor/meteor"), {
    Meteor(v) {
        Meteor = v;
    }

}, 0);
let Mongo;
module.watch(require("meteor/mongo"), {
    Mongo(v) {
        Mongo = v;
    }

}, 1);
let check;
module.watch(require("meteor/check"), {
    check(v) {
        check = v;
    }

}, 2);
const Tasks = new Mongo.Collection('tasks');

if (Meteor.isServer) {
    Meteor.publish('tasks', function tasksPublication() {
        return Tasks.find({
            $or: [{
                private: {
                    $ne: true
                }
            }, {
                owner: this.userId
            }]
        });
    });
}

Meteor.methods({
    'tasks.insert'(text) {
        check(text, String);

        if (!Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }

        Tasks.insert({
            text,
            createdAt: new Date(),
            checked: false,
            owner: Meteor.userId(),
            username: Meteor.user().username
        });
    },

    'tasks.remove'(taskId) {
        check(taskId, String);
        const task = Tasks.findOne(taskId);

        if (task.private && task.owner !== Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }

        Tasks.remove(taskId);
    },

    'tasks.setChecked'(taskId, setChecked) {
        check(taskId, String);
        check(setChecked, Boolean);
        const task = Tasks.findOne(taskId);

        if (task.private && task.owner !== Meteor.userId()) {
            throw new Meteor.Error('not-authorized');
        }

        Tasks.update(taskId, {
            $set: {
                checked: setChecked
            }
        });
    },

    'tasks.setPrivate'(taskId, setToPrivate) {
        check(taskId, String);
        check(setToPrivate, Boolean);
        const task = Tasks.findOne(taskId);

        if (task.owner !== Meteor.userId()) {
            throw new Meteor.Error('not authorized');
        }

        Tasks.update(taskId, {
            $set: {
                private: setToPrivate
            }
        });
    }

});
///////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
module.watch(require("../imports/api/tasks.js"));
///////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFza3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIlRhc2tzIiwiTWV0ZW9yIiwid2F0Y2giLCJyZXF1aXJlIiwidiIsIk1vbmdvIiwiY2hlY2siLCJDb2xsZWN0aW9uIiwiaXNTZXJ2ZXIiLCJwdWJsaXNoIiwidGFza3NQdWJsaWNhdGlvbiIsImZpbmQiLCIkb3IiLCJwcml2YXRlIiwiJG5lIiwib3duZXIiLCJ1c2VySWQiLCJtZXRob2RzIiwidGV4dCIsIlN0cmluZyIsIkVycm9yIiwiaW5zZXJ0IiwiY3JlYXRlZEF0IiwiRGF0ZSIsImNoZWNrZWQiLCJ1c2VybmFtZSIsInVzZXIiLCJ0YXNrSWQiLCJ0YXNrIiwiZmluZE9uZSIsInJlbW92ZSIsInNldENoZWNrZWQiLCJCb29sZWFuIiwidXBkYXRlIiwiJHNldCIsInNldFRvUHJpdmF0ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsT0FBT0MsTUFBUCxDQUFjO0FBQUNDLFdBQU0sTUFBSUE7QUFBWCxDQUFkO0FBQWlDLElBQUlDLE1BQUo7QUFBV0gsT0FBT0ksS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDRixXQUFPRyxDQUFQLEVBQVM7QUFBQ0gsaUJBQU9HLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSUMsS0FBSjtBQUFVUCxPQUFPSSxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNFLFVBQU1ELENBQU4sRUFBUTtBQUFDQyxnQkFBTUQsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJRSxLQUFKO0FBQVVSLE9BQU9JLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ0csVUFBTUYsQ0FBTixFQUFRO0FBQUNFLGdCQUFNRixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBSXBMLE1BQU1KLFFBQVEsSUFBSUssTUFBTUUsVUFBVixDQUFxQixPQUFyQixDQUFkOztBQUVQLElBQUlOLE9BQU9PLFFBQVgsRUFBcUI7QUFDakJQLFdBQU9RLE9BQVAsQ0FBZSxPQUFmLEVBQXdCLFNBQVNDLGdCQUFULEdBQTRCO0FBQ2hELGVBQU9WLE1BQU1XLElBQU4sQ0FBVztBQUNkQyxpQkFBSyxDQUNEO0FBQUVDLHlCQUFTO0FBQUVDLHlCQUFLO0FBQVA7QUFBWCxhQURDLEVBRUQ7QUFBRUMsdUJBQVUsS0FBS0M7QUFBakIsYUFGQztBQURTLFNBQVgsQ0FBUDtBQU1ILEtBUEQ7QUFRSDs7QUFFRGYsT0FBT2dCLE9BQVAsQ0FBZTtBQUNYLG1CQUFlQyxJQUFmLEVBQXFCO0FBQ2pCWixjQUFNWSxJQUFOLEVBQVlDLE1BQVo7O0FBRUEsWUFBSSxDQUFFbEIsT0FBT2UsTUFBUCxFQUFOLEVBQXVCO0FBQ25CLGtCQUFNLElBQUlmLE9BQU9tQixLQUFYLENBQWlCLGdCQUFqQixDQUFOO0FBQ0g7O0FBRURwQixjQUFNcUIsTUFBTixDQUFhO0FBQ1RILGdCQURTO0FBRVRJLHVCQUFXLElBQUlDLElBQUosRUFGRjtBQUdUQyxxQkFBUyxLQUhBO0FBSVRULG1CQUFPZCxPQUFPZSxNQUFQLEVBSkU7QUFLVFMsc0JBQVV4QixPQUFPeUIsSUFBUCxHQUFjRDtBQUxmLFNBQWI7QUFPSCxLQWZVOztBQWlCWCxtQkFBZUUsTUFBZixFQUF1QjtBQUNuQnJCLGNBQU1xQixNQUFOLEVBQWNSLE1BQWQ7QUFFQSxjQUFNUyxPQUFPNUIsTUFBTTZCLE9BQU4sQ0FBY0YsTUFBZCxDQUFiOztBQUNBLFlBQUlDLEtBQUtmLE9BQUwsSUFBZ0JlLEtBQUtiLEtBQUwsS0FBZWQsT0FBT2UsTUFBUCxFQUFuQyxFQUFvRDtBQUNoRCxrQkFBTSxJQUFJZixPQUFPbUIsS0FBWCxDQUFpQixnQkFBakIsQ0FBTjtBQUNIOztBQUVEcEIsY0FBTThCLE1BQU4sQ0FBYUgsTUFBYjtBQUNILEtBMUJVOztBQTRCWCx1QkFBbUJBLE1BQW5CLEVBQTJCSSxVQUEzQixFQUF1QztBQUNuQ3pCLGNBQU1xQixNQUFOLEVBQWNSLE1BQWQ7QUFDQWIsY0FBTXlCLFVBQU4sRUFBa0JDLE9BQWxCO0FBRUEsY0FBTUosT0FBTzVCLE1BQU02QixPQUFOLENBQWNGLE1BQWQsQ0FBYjs7QUFDQSxZQUFJQyxLQUFLZixPQUFMLElBQWdCZSxLQUFLYixLQUFMLEtBQWVkLE9BQU9lLE1BQVAsRUFBbkMsRUFBb0Q7QUFDaEQsa0JBQU0sSUFBSWYsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFFRHBCLGNBQU1pQyxNQUFOLENBQWFOLE1BQWIsRUFBcUI7QUFBRU8sa0JBQU07QUFBRVYseUJBQVNPO0FBQVg7QUFBUixTQUFyQjtBQUNILEtBdENVOztBQXdDWCx1QkFBbUJKLE1BQW5CLEVBQTJCUSxZQUEzQixFQUF5QztBQUNyQzdCLGNBQU1xQixNQUFOLEVBQWNSLE1BQWQ7QUFDQWIsY0FBTTZCLFlBQU4sRUFBb0JILE9BQXBCO0FBRUEsY0FBTUosT0FBTzVCLE1BQU02QixPQUFOLENBQWNGLE1BQWQsQ0FBYjs7QUFFQSxZQUFJQyxLQUFLYixLQUFMLEtBQWVkLE9BQU9lLE1BQVAsRUFBbkIsRUFBcUM7QUFDakMsa0JBQU0sSUFBSWYsT0FBT21CLEtBQVgsQ0FBaUIsZ0JBQWpCLENBQU47QUFDSDs7QUFFRHBCLGNBQU1pQyxNQUFOLENBQWFOLE1BQWIsRUFBcUI7QUFBRU8sa0JBQU07QUFBRXJCLHlCQUFTc0I7QUFBWDtBQUFSLFNBQXJCO0FBQ0g7O0FBbkRVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNqQkFyQyxPQUFPSSxLQUFQLENBQWFDLFFBQVEseUJBQVIsQ0FBYixFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcblxuZXhwb3J0IGNvbnN0IFRhc2tzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Rhc2tzJyk7XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICBNZXRlb3IucHVibGlzaCgndGFza3MnLCBmdW5jdGlvbiB0YXNrc1B1YmxpY2F0aW9uKCkge1xuICAgICAgICByZXR1cm4gVGFza3MuZmluZCh7XG4gICAgICAgICAgICAkb3I6IFtcbiAgICAgICAgICAgICAgICB7IHByaXZhdGU6IHsgJG5lOiB0cnVlIH0gfSxcbiAgICAgICAgICAgICAgICB7IG93bmVyOiAgICB0aGlzLnVzZXJJZCAgfVxuICAgICAgICAgICAgXVxuICAgICAgICB9KVxuICAgIH0pXG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAndGFza3MuaW5zZXJ0Jyh0ZXh0KSB7XG4gICAgICAgIGNoZWNrKHRleHQsIFN0cmluZyk7XG5cbiAgICAgICAgaWYoICEgTWV0ZW9yLnVzZXJJZCgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdub3QtYXV0aG9yaXplZCcpO1xuICAgICAgICB9XG5cbiAgICAgICAgVGFza3MuaW5zZXJ0KHtcbiAgICAgICAgICAgIHRleHQsXG4gICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICBjaGVja2VkOiBmYWxzZSxcbiAgICAgICAgICAgIG93bmVyOiBNZXRlb3IudXNlcklkKCksXG4gICAgICAgICAgICB1c2VybmFtZTogTWV0ZW9yLnVzZXIoKS51c2VybmFtZSxcbiAgICAgICAgfSlcbiAgICB9LFxuXG4gICAgJ3Rhc2tzLnJlbW92ZScodGFza0lkKSB7XG4gICAgICAgIGNoZWNrKHRhc2tJZCwgU3RyaW5nKTtcblxuICAgICAgICBjb25zdCB0YXNrID0gVGFza3MuZmluZE9uZSh0YXNrSWQpO1xuICAgICAgICBpZiggdGFzay5wcml2YXRlICYmIHRhc2sub3duZXIgIT09IE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKVxuICAgICAgICB9XG5cbiAgICAgICAgVGFza3MucmVtb3ZlKHRhc2tJZCk7XG4gICAgfSxcblxuICAgICd0YXNrcy5zZXRDaGVja2VkJyh0YXNrSWQsIHNldENoZWNrZWQpIHtcbiAgICAgICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgICAgICBjaGVjayhzZXRDaGVja2VkLCBCb29sZWFuKTtcblxuICAgICAgICBjb25zdCB0YXNrID0gVGFza3MuZmluZE9uZSh0YXNrSWQpO1xuICAgICAgICBpZiAodGFzay5wcml2YXRlICYmIHRhc2sub3duZXIgIT09IE1ldGVvci51c2VySWQoKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignbm90LWF1dGhvcml6ZWQnKVxuICAgICAgICB9XG5cbiAgICAgICAgVGFza3MudXBkYXRlKHRhc2tJZCwgeyAkc2V0OiB7IGNoZWNrZWQ6IHNldENoZWNrZWQgfSB9KVxuICAgIH0sXG5cbiAgICAndGFza3Muc2V0UHJpdmF0ZScodGFza0lkLCBzZXRUb1ByaXZhdGUpIHtcbiAgICAgICAgY2hlY2sodGFza0lkLCBTdHJpbmcpO1xuICAgICAgICBjaGVjayhzZXRUb1ByaXZhdGUsIEJvb2xlYW4pO1xuXG4gICAgICAgIGNvbnN0IHRhc2sgPSBUYXNrcy5maW5kT25lKHRhc2tJZCk7XG5cbiAgICAgICAgaWYoIHRhc2sub3duZXIgIT09IE1ldGVvci51c2VySWQoKSApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ25vdCBhdXRob3JpemVkJyk7XG4gICAgICAgIH1cblxuICAgICAgICBUYXNrcy51cGRhdGUodGFza0lkLCB7ICRzZXQ6IHsgcHJpdmF0ZTogc2V0VG9Qcml2YXRlIH0gfSlcbiAgICB9XG59KVxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2FwaS90YXNrcy5qcyc7XG4iXX0=
